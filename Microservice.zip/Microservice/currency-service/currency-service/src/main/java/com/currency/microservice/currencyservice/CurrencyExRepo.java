package com.currency.microservice.currencyservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyExRepo extends JpaRepository<CurrencyExchange,Long> {
    CurrencyExchange findByFromAndTo(String from,String to);
}
